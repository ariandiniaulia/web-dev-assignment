
<?php $__env->startSection('content'); ?>
<body class="bg-success p-2 text-dark bg-opacity-25">
    <section>
        <div class="container mt-5">
            <h1>Edit Data Mahasiswa</h1>
            <div class="row">
                <div class="col-lg-8">
                <form action="<?php echo e(url('/update/'.$data->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nama">Nama*</label>
                        <input type="text" name="nama" class="form-control" placeholder="Nama Lengkap Mahasiswa" value="<?php echo e($data->nama); ?>">
                    </div>
                    <div class="form-group">
                        <label for="nama">NIM*</label>
                        <input type="text" name="nim" class="form-control" placeholder="Nomor Induk Mahasiswa" value="<?php echo e($data->nim); ?>">
                    </div>
                    <div class="form-group">
                        <label for="nama">Alamat*</label>
                        <textarea class="form-control" name="alamat" placeholder="Alamat Lengkap Mahasiswa"> <?php echo e($data->alamat); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="nama">Prodi*</label>
                        <input type="text" name="prodi" class="form-control" placeholder="Program Studi Mahasiswa" value="<?php echo e($data->prodi); ?>">
                    </div>
                    <div class="form-group">
                        <label for="nama">Fakultas*</label>
                        <input type="text" name="fakultas" class="form-control" placeholder="Fakultas Mahasiswa" value="<?php echo e($data->fakultas); ?>">
                    </div>
                    <div class="form-group mt-2">
                        <button type="submit" class="btn btn-secondary">Update Data</button>
                    </div>
                </div>
            </form>
            </div>
        </div>
    </section>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crudlaravel\resources\views/show.blade.php ENDPATH**/ ?>