

<?php $__env->startSection('content'); ?>
<body class="bg-success p-2 text-dark bg-opacity-25">
<section>
    <div class="container mt-5">
        <div class="row">
        <h1 class="text-center">DATA MAHASISWA</h1>
            <div class="col-lg-8">
                <a href="<?php echo e(url('create')); ?>" class="btn btn-secondary mt-2">+ Tambah</a>
                <div class="row g-3 align-items-center mt-2 ">
                    <div class="col-auto">
                    <form action="/" method="GET">
                        <input class="bg-success p-2 text-dark bg-opacity-10" type="search" id="inputPassword6" name="search" class="form-control" aria-describedby="passwordHelpInline">
                    </form> 
                    </div> 
                </div>
            </div>

            <div class="container mt-5">
                <table class="table table-bordered table-striped table-secondary table align-middle">
                    <tr class = "text-center">
                        <th>No</th>
                        <th>Nama</th>
                        <th>NIM</th>
                        <th>Alamat</th>
                        <th>Prodi</th>
                        <th>Fakultas</th>
                        <th>Aksi</th>

                    </tr>
                    <?php
                        $no = 1;
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $dataMahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="dataMahasiswa"><?php echo e($index + $data->firstItem()); ?></th>
                        <td><?php echo e($dataMahasiswa-> nama); ?> </td>
                        <td><?php echo e($dataMahasiswa-> nim); ?> </td>
                        <td><?php echo e($dataMahasiswa-> alamat); ?> </td>
                        <td><?php echo e($dataMahasiswa-> prodi); ?> </td>
                        <td><?php echo e($dataMahasiswa-> fakultas); ?> </td>
                        <td>
                            <a href="<?php echo e(url('/show/'.$dataMahasiswa->id)); ?>" class="btn btn-warning">Edit</a>
                            <a href="#" class="btn btn-danger delete" data-id="<?php echo e($dataMahasiswa-> id); ?>">Hapus</a>
                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <?php echo e($data->links()); ?>

            </div>
        </div>
    </div>
    </section>
</body>
<script>
    $('.delete').click(function(){
        var mahasiswaid = $(this).attr('data-id');
        swal({
            title: "Yakin?",
            text: "Kamu akan menghapus data ini?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willDelete) => {
        if (willDelete) {
            window.location = "/destroy/"+mahasiswaid+" ",
            swal("Data sukses dihapus", {
            icon: "success",
        });
        } else {
            swal("Data tidak jadi dihapus");
        }
        });
    });
    
</script>
<script>
    <?php if(Session::has('succes')): ?>
        toastr.success("<?php echo e(Session::get('succes')); ?>")
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crudlaravel\resources\views/index.blade.php ENDPATH**/ ?>