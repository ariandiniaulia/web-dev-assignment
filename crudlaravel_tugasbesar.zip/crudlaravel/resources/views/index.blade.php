@extends('layouts.default')

@section('content')
<body class="bg-success p-2 text-dark bg-opacity-25">
<section>
    <div class="container mt-5">
        <div class="row">
        <h1 class="text-center">DATA MAHASISWA</h1>
            <div class="col-lg-8">
                <a href="{{url('create')}}" class="btn btn-secondary mt-2">+ Tambah</a>
                <div class="row g-3 align-items-center mt-2 ">
                    <div class="col-auto">
                    <form action="/" method="GET">
                        <input class="bg-success p-2 text-dark bg-opacity-10" type="search" id="inputPassword6" name="search" class="form-control" aria-describedby="passwordHelpInline">
                    </form> 
                    </div> 
                </div>
            </div>

            <div class="container mt-5">
                <table class="table table-bordered table-striped table-secondary table align-middle">
                    <tr class = "text-center">
                        <th>No</th>
                        <th>Nama</th>
                        <th>NIM</th>
                        <th>Alamat</th>
                        <th>Prodi</th>
                        <th>Fakultas</th>
                        <th>Aksi</th>

                    </tr>
                    @php
                        $no = 1;
                    @endphp
                    @foreach ($data as $index => $dataMahasiswa)
                    <tr>
                        <th scope="dataMahasiswa">{{$index + $data->firstItem()}}</th>
                        <td>{{ $dataMahasiswa-> nama}} </td>
                        <td>{{ $dataMahasiswa-> nim}} </td>
                        <td>{{ $dataMahasiswa-> alamat}} </td>
                        <td>{{ $dataMahasiswa-> prodi}} </td>
                        <td>{{ $dataMahasiswa-> fakultas}} </td>
                        <td>
                            <a href="{{ url('/show/'.$dataMahasiswa->id) }}" class="btn btn-warning">Edit</a>
                            <a href="#" class="btn btn-danger delete" data-id="{{ $dataMahasiswa-> id}}">Hapus</a>
                        </td>
                    @endforeach
                </table>
                {{ $data->links() }}
            </div>
        </div>
    </div>
    </section>
</body>
<script>
    $('.delete').click(function(){
        var mahasiswaid = $(this).attr('data-id');
        swal({
            title: "Yakin?",
            text: "Kamu akan menghapus data ini?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willDelete) => {
        if (willDelete) {
            window.location = "/destroy/"+mahasiswaid+" ",
            swal("Data sukses dihapus", {
            icon: "success",
        });
        } else {
            swal("Data tidak jadi dihapus");
        }
        });
    });
    
</script>
<script>
    @if (Session::has('succes'))
        toastr.success("{{Session::get('succes') }}")
    @endif
</script>
@endsection