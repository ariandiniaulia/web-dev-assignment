@extends('layouts.default')
@section('content')
<body class="bg-success p-2 text-dark bg-opacity-25">
    <section>
        <div class="container mt-5">
            <h1>Masukkan Data Mahasiswa</h1>
            <div class="row">
                <div class="col-lg-8">
                    <form action="{{ url('/store') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="nama">Nama*</label>
                        <input type="text" name="nama" class="form-control" placeholder="Nama Lengkap Anda">
                    </div>
                    <div class="form-group">
                        <label for="nama">NIM*</label>
                        <input type="text" name="nim" class="form-control" placeholder="NIM Anda">
                    </div>
                    <div class="form-group">
                        <label for="nama">Alamat*</label>
                        <textarea class="form-control" name="alamat" placeholder="Alamat Lengkap Anda"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="nama">Prodi*</label>
                        <input type="text" name="prodi" class="form-control" placeholder="Program Studi Anda">
                    </div>
                    <div class="form-group">
                        <label for="nama">Fakultas*</label>
                        <input type="text" name="fakultas" class="form-control" placeholder="Fakultas Anda">
                    </div>
                    <div class="form-group mt-2">
                        <button type="submit" class="btn btn-secondary">Tambah Data</button>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
@endsection