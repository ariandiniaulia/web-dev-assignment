@extends('layouts.default')

@section('content')
<body class="bg-success p-2 text-dark bg-opacity-25">
<section>
    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-8">
                <h1>CRUD LARAVEL</h1>
                <a href="{{url('create')}}" class="btn btn-secondary mt-2">+ Tambah</a>
            </div>
            <div class="container mt-5">
                <table class="table table-bordered table-striped table-secondary table align-middle">
                    <tr class = "text-center">
                        <th>No</th>
                        <th>Nama</th>
                        <th>NIM</th>
                        <th>Alamat</th>
                        <th>Prodi</th>
                        <th>Fakultas</th>
                        <th>Aksi</th>

                    </tr>
                    @foreach ($data as $dataMahasiswa)
                    <tr>
                        <td>{{ $dataMahasiswa-> id}} </td>
                        <td>{{ $dataMahasiswa-> nama}} </td>
                        <td>{{ $dataMahasiswa-> nim}} </td>
                        <td>{{ $dataMahasiswa-> alamat}} </td>
                        <td>{{ $dataMahasiswa-> prodi}} </td>
                        <td>{{ $dataMahasiswa-> fakultas}} </td>
                        <td>
                            <a href="{{ url('/show/'.$dataMahasiswa->id) }}" class="btn btn-warning">Edit</a>
                            <a href="{{ url('/destroy/'.$dataMahasiswa->id) }}" class="btn btn-danger">Hapus</a>
                        </td>
                    @endforeach
                </table>
            </div>
        </div>
    </div>
    </section>
</body>
@endsection