@extends('layouts.default')
@section('content')
<body class="bg-success p-2 text-dark bg-opacity-25">
    <section>
        <div class="container mt-5">
            <h1>Edit Data Mahasiswa</h1>
            <div class="row">
                <div class="col-lg-8">
                    <form action="{{ url('/update/'. $data->id) }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="nama">Nama*</label>
                        <input type="text" name="nama" class="form-control" placeholder="Nama Lengkap Anda" value="{{$data->nama}}">
                    </div>
                    <div class="form-group">
                        <label for="nama">NIM*</label>
                        <input type="text" name="nim" class="form-control" placeholder="NIM Anda" value="{{$data->nim}}">
                    </div>
                    <div class="form-group">
                        <label for="nama">Alamat*</label>
                        <textarea class="form-control" name="alamat" placeholder="Alamat Lengkap Anda">{{ $data->alamat }}</textarea>
                    </div>
                    <div class="form-group">
                        <label for="nama">Prodi*</label>
                        <input type="text" name="prodi" class="form-control" placeholder="Program Studi Anda" value="{{$data->prodi}}">
                    </div>
                    <div class="form-group">
                        <label for="nama">Fakultas*</label>
                        <input type="text" name="fakultas" class="form-control" placeholder="Fakultas Anda" value="{{$data->fakultas}}">
                    </div>
                    <div class="form-group mt-2">
                        <button type="submit" class="btn btn-secondary">Tambah Data</button>
                    </div>
                    <div class="form-group mt-3">
                        <button href="{{ url('/') }}">Kembali Ke Halaman Utama</button>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
@endsection